To use the following scripts please create a folder Data and import the provided data there and a folder Csv_to_database where we will create csv files
