drop table host;

drop table has_host_verification;
drop table has_amenity;

drop table listing_calendar;
drop table review;

drop table listing;
drop table host;

drop table Host_verification;
drop table Amenity;



drop table neighbourhood;
drop table bed_type;
drop table room_type;
drop table property_type;
drop table host_response_time;
drop table city;
drop table country;
drop table cancellation_policy;

