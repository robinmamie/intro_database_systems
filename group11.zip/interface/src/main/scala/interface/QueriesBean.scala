package interface

import scalafx.beans.property.{BooleanProperty, StringProperty}
import scalafx.collections.ObservableBuffer

import database._
import database.Parameters.Result

object QueriesBean {

  class Item(initialSelection: Boolean, val name: String, val file: String) {
    val selected = BooleanProperty(initialSelection)
    override def toString = name
  }

  val queries = ObservableBuffer[Item](
    (1 to 22).map { t => new Item(false, "Query nb. " + t, "sql/" + t + ".sql") }
  )

  val results = ObservableBuffer[Result]()

  def setResults(newResults: List[Result]): Unit = {
    results.clear()
    results ++= newResults
  }

  val q1 = StringProperty("8")
  val q5 = StringProperty("Viajes Eco")
}
