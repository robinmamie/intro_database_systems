package interface

import scalafx.scene.layout.Pane

object Center extends Pane {

  children = Welcome

}
