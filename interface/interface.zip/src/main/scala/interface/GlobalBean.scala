package interface

import scalafx.beans.property.StringProperty

object GlobalBean {

    val requests = StringProperty("50")

}
