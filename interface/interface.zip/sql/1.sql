SELECT ROUND ( AVG (l.price) , 2)
FROM Listing l
WHERE l.bedrooms = #
